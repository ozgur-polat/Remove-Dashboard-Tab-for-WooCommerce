=== Plugin Name ===

Contributors:      Özgür Polat
Plugin Name:       Remove Dashboard Tab for WooCommerce
Plugin URI:        https://digitalworkshouse.com/wordpress/
Tags:              woocommerce, account, menu, dashboard, tab, remove 
Author URI:        https://digitalworkshouse.com/
Author:            Digital Works House
Donate link:       (a link for donating)
Requires at least: (minimum required WP) 
Tested up to:      5.6
Stable tag:        1.0
Version:           1.0
License:           GPLv2 or later
License URI:       http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Simple plugin to smoothly remove Dashboard tab on the account area of WooCommerce. 
Deactivation brings the Dashboard back and activation hides it. 
== Installation ==
Installing and activating the plugin is enough to make it work.
== Upgrade Notice ==
This is the initial version.
== Donations ==
All donations can go to the global funds for the current pandemic or other great causes.
We will be happy to be in touch: https://digitalworkshouse.com/contact-us